package utils.ObserverPattern;

public interface Observer {
    void update();
}
