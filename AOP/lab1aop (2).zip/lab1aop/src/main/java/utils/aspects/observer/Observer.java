package utils.aspects.observer;

public interface Observer {
    void update();
}
