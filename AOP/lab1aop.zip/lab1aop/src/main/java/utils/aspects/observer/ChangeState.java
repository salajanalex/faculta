package utils.aspects.observer;

public @interface ChangeState {
}
