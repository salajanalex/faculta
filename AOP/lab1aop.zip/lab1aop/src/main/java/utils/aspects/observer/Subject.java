package utils.aspects.observer;

public interface Subject {
}
