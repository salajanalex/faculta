
// pt popup la apasarea butonului add
function addPopup() {
    window.alert("Participantul a fost adaugat cu succes!")
}
